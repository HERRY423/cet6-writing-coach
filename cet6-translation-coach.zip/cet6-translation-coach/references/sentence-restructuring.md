# 句子重构套路：从中文意合到英文形合

核心心法：**中文靠意思串，英文靠结构串。** 先砍出英语主干（SVO），再把其余信息"降级"挂上去。

## 通用四步主干提取模板
1. **谁**（主语）—— 中文省略就补出来；无施动者考虑被动或形式主语 it。
2. **做什么**（谓语动词）—— 选最准的实义动词。
3. **什么**（宾语/表语）。
4. **其余全部降级**：时间/地点/原因/方式/条件 → 状语（介词短语 / 从句 / 非谓语），修饰名词的长定语 → 定语从句 / 分词 / of 结构。

---

## 难点一：无主句（中文最常见）
中文"应该……""可以看到……""据说……""每年举行……"没主语。三种英译出路：

1. **补泛指主语**：we / people / one。
   "应该保护传统文化" → We should protect traditional culture.
2. **用被动**（更正式，推荐用于说明文）：
   "每年都会举办庙会" → Temple fairs are held every year.
3. **形式主语 it**：
   "据说这座桥有一千年历史" → It is said that the bridge has a history of 1,000 years.

> 口诀：**无主句先想被动，再想 it，最后才补 we/people。**

## 难点二：流水句（一逗到底）
中文一句话用逗号串好几个动作。**别塞成一个英文长句**，按意群拆。

原文："长城始建于公元前 7 世纪，全长超过两万公里，是世界上最伟大的建筑之一。"
- 拆意群：[始建时间] [全长] [地位]
- 译：The Great Wall was first built in the 7th century BC. **Stretching** over 20,000 kilometers, it is **regarded as** one of the greatest constructions in the world.
- 手法：第一个意群独立成句；第二个意群用分词 Stretching 降级；第三个意群做主句。

**连接工具箱**（拆开后补逻辑）：and / while / which / so that / as / by doing / when。

## 难点三：把字句 / 被字句
- "把 A 译成 B" → translate A into B（把字句多对应 SVOC 或介词结构）。
- "A 被 B 称为 C" → A is called C by B / A is known as C.
- "人们把京剧称为国粹" → Peking Opera is regarded as the quintessence of Chinese culture.

## 难点四：连动句（一个主语多个动作）
中文"他走进房间坐下打开电脑"。英文一个主语只能一个谓语，其余降级：
- 并列：用 and。He entered the room, sat down, **and** turned on the computer.
- 主次分明：次要动作用非谓语。**Entering** the room, he turned on the computer.（伴随/先后）

## 难点五：长定语后置
中文"由手工艺人世代相传的技艺"——定语很长，英文后置。
- 定语从句：a craft **that has been passed down** by artisans for generations.
- 分词后置：a craft **passed down** by artisans for generations.
- of 结构：the craft **of** paper cutting.

## 难点六：主题句 / 话题前置
中文"中国画，历史悠久，种类繁多"——"中国画"是话题不是主语。
- 译：Chinese painting **has a long history and comes in many varieties.**（把话题变主语 + 并列谓语）

---

## 降级工具速查
| 中文成分 | 英文降级手段 |
|---|---|
| 背景/伴随动作 | 现在分词 doing |
| 已完成的前提 | 过去分词 done / having done |
| 目的 | to do / so as to / in order to |
| 原因 | as / because / 介词 due to |
| 时间地点 | 介词短语 in / during / at |
| 长修饰语 | 定语从句 which/that |
| 补充说明 | 同位语（逗号 + 名词短语，**专门用于中国特色词加注**） |
