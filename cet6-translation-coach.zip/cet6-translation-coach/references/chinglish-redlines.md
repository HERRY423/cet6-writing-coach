# 中式直译红线对照表（看到默认替换）

汉译英最大失分源不是不会词，是**逐字硬译**。下面是六级高频中式陷阱，分四类。

## 一、范畴词冗余（中文爱加"工作/问题/情况/水平/现象"，英文删掉）
中文用范畴词凑双音节，英文里多半是废话，直接删。

| 中式 → | 地道 |
|---|---|
| improve the level of people's life | raise living standards |
| the work of teaching | teaching |
| the problem of pollution | pollution |
| economic development situation | economic development |
| solve the problem of unemployment | reduce / tackle unemployment |
| the phenomenon of aging | population aging / an aging population |
| accelerate the pace of construction | accelerate construction |

## 二、动词搭配硬伤（高频且阅卷一眼看出）
| 中式 → | 正确 |
|---|---|
| learn knowledge | acquire / gain knowledge |
| pay attention on | pay attention **to** |
| pay attention to do | pay attention to **doing** |
| improve / raise the economy | boost / grow the economy |
| open the light | turn **on** the light |
| eat medicine | take medicine |
| say a lie | tell a lie |
| see a book | read a book |
| insist to do | insist **on doing** |
| discuss about | discuss（无 about） |
| emphasize on | emphasize（无 on） |
| affect to | affect（及物，无 to） |

## 三、结构 / 逻辑中式（意合→形合没转过来）
| 中式直译 → | 地道改写 |
|---|---|
| Because..., so... | Because...,（删 so）/ ..., so... 二选一 |
| Although..., but... | Although...,（删 but） |
| people think / we all know（无主句逐字译） | It is believed / widely acknowledged that... |
| With the development of society, ...（万能开头滥用） | As society develops / advances, ... |
| There are many people think... | Many people think... / A growing number of people believe... |
| 把"逗号流水句"塞成一个长句 | 按意群拆成 2–3 句，用 and/which/while 连接 |

## 四、时态 / 语态陷阱（六级翻译重灾区）
- **历史/朝代/起源**：必须过去时。"剪纸起源于汉代" → Paper cutting originated in the Han Dynasty.（不是 originates）
- **普遍事实/现状/习俗**：现在时。"春节是最重要的节日" → The Spring Festival is the most important festival.
- **延续到现在的状态**：现在完成时。"已有两千多年历史" → has a history of over 2,000 years / has existed for over 2,000 years.
- **无主句默认被动**：
  - "据说……" → It is said that...
  - "人们普遍认为……" → It is widely believed that...
  - "中国结被视为……" → The Chinese knot is regarded as...
  - "节日期间会举行各种活动" → Various activities are held during the festival.

## 五、数字 / 量级表达
- "数百年" → centuries / hundreds of years（不是 several hundreds year）
- "约 / 大约" → about / approximately / around
- "占……的 70%" → account for 70% of...
- "增长了两倍" → triple / increase threefold（注意"增长了 N 倍"= 变为 N+1 倍）
- "成千上万的" → thousands of / tens of thousands of

> 教练用法：批改时凡命中以上任何一行，标 🟡（中式）或 🔴（搭配硬错），并给地道替换。
