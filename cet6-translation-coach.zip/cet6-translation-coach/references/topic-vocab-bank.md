# 五大题材高频词 + 硬搭配

六级翻译题材固定。背搭配（成块）比背单词更管用。每类给"高频名词/动词 + 必会搭配 + 一句模板"。

## 一、文化 / 习俗
高频词：tradition, custom, heritage, ritual, symbolize, inherit, festival, ancestor, celebrate, blessing。
硬搭配：
- be passed down from generation to generation（代代相传）
- symbolize good fortune / unity / harmony（象征好运/团结/和谐）
- play a vital role in（在……中起关键作用）
- be deeply rooted in Chinese culture（深植于中国文化）
- cultural heritage / intangible cultural heritage（文化遗产 / 非物质文化遗产）
模板：__ , a time-honored Chinese tradition, symbolizes __ and is celebrated by __.

## 二、历史 / 朝代
高频词：dynasty, originate, date back to, ancient, found, reign, civilization, ruins, relic。
硬搭配：
- date back to / can be traced back to（追溯到）
- originate in the ... Dynasty（起源于……朝）
- have a history of over ... years（有……年历史）
- be regarded as one of the greatest ... in the world（被视为世界上最伟大的……之一）
- the cradle of Chinese civilization（中华文明的摇篮）
模板：__ originated in the __ Dynasty and has a history of over __ years.
⚠️ 全段过去时为主，"延续至今"用现在完成时。

## 三、经济
高频词：economy, growth, development, market, industry, reform, boost, consumption, investment, urbanization。
硬搭配：
- boost / drive / fuel economic growth（拉动经济增长）
- account for ... % of GDP（占 GDP 的……）
- raise living standards（提高生活水平）
- reform and opening-up（改革开放）
- become the world's second-largest economy（成为世界第二大经济体）
- narrow the gap between urban and rural areas（缩小城乡差距）
模板：Over the past decades, China's economy has __ , making it __.
⚠️ "近几十年来"配现在完成时。

## 四、社会 / 民生
高频词：population, aging, education, urbanization, employment, welfare, migrant, public, awareness。
硬搭配：
- an aging population / population aging（人口老龄化）
- a growing number of（越来越多的）
- raise public awareness of（提高公众对……的意识）
- improve people's well-being / livelihood（改善民生）
- bridge / narrow the gap（缩小差距）
- pose a challenge to（对……构成挑战）
模板：With __ , an increasing number of people __, which has __.

## 五、科技 / 现代生活
高频词：technology, innovation, digital, e-commerce, mobile payment, artificial intelligence, transform, application, infrastructure。
硬搭配：
- with the rapid development of technology（用 As technology advances 更佳）
- transform the way people live / work（改变人们的生活/工作方式）
- play an increasingly important role in（日益重要）
- be widely used / applied in（广泛应用于）
- high-speed rail / mobile payment / e-commerce（高铁/移动支付/电商）
- bring great convenience to（给……带来极大便利）
模板：__ has transformed the way people __ , bringing great convenience to daily life.

---

## 跨题材万能动词升级（干掉 make/have/get/do）
| 平淡 | 升级 |
|---|---|
| make ... develop | promote / boost / drive ... |
| have a long history | boast a long history / date back to |
| is / become important | play a vital role / serve as a cornerstone |
| many people like | be widely loved / enjoy great popularity |
| use ... a lot | be widely used / applied |
| show / express（情感象征） | symbolize / represent / embody |
| is called | be known / regarded / referred to as |

## 跨题材万能连接（衔接自然 = 上 14 的关键）
顺接：and, in addition, moreover, what's more
因果：as, since, therefore, as a result, consequently
转折：however, while, whereas, nevertheless
举例：such as, for instance, including
总结：in short, overall, all in all
