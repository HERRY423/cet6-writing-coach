# 三大底层心法：从"词汇对译"到"满分译文"

这是本 skill 的**理论内核**。六步法是流程，这三条是流程背后的"为什么"。教练在批改/讲解时应主动用这三层透视译文：先看**结构**（句子骨架对不对），再看**词境**（词选得贴不贴语境），最后看**连贯地道**（读起来像不像母语者）。

---

# 一、底层逻辑突破：从"词汇对译"到"结构重构"

## 核心命题
汉译英最大的认知误区是"把中文词一个个换成英文词"。**真正的翻译是先拆解中文的意义结构，再用英文的结构习惯重新搭建。** 词是砖，结构是图纸——图纸错了，砖再好也是危房。

## 中英结构的根本差异：意合 vs 形合
| | 中文（意合 parataxis） | 英文（形合 hypotaxis） |
|---|---|---|
| 靠什么连句 | 靠**意思**和语序，连词常省略 | 靠**显性连接词和语法形态**（that/which/-ing/介词） |
| 句子形态 | 短句铺排、流水句、竹节式 | 一个主干 + 层层从属，葡萄串式 |
| 信息排布 | 重要信息常**后置**（先铺垫后结论） | 重要信息常**前置**（主句先行，修饰后挂） |
| 主语 | 可省略、可无主语 | 必须有主语（实在没有就用 it / 被动） |

**一句话**：中文是"把句子摊平排开"，英文是"把句子立体搭起来"。重构 = 把摊平的中文**重新立体化**。

## 结构重构四步操作法
拿到一个中文句，**不要从第一个词开始翻**，先做结构分析：

**第 1 步：找语义重心（哪个是主句）**
问"这句话最核心要说的一件事是什么"。那件事做**主句**，其余全是配料。
- 例："大湾区是中国开放程度最高的区域之一，在国家经济发展中具有重要战略地位。"
- 语义重心是后半句"具有战略地位"→ 它做主句，"是……之一"降级成 As 状语。
- → As one of the most open regions in China, **it holds a key strategic position**...

**第 2 步：定主语与语态**
- 有明确施动者 → 主动。
- 无主句 / 强调动作本身 / 施动者不重要 → 被动或 it 形式主语。
- "据说""人们认为""每年举办"→ It is said that / are held。

**第 3 步：把配料"降级"挂上去**
中文的并列分句，到英文里大多数应该**降级**为非主句成分。降级工具箱：

| 中文配料类型 | 英文降级手段 | 例 |
|---|---|---|
| 并列的"拥有/具有" | with + 名词短语 | ..., **with** advanced infrastructure |
| 背景身份"作为/是…之一" | As + 名词 状语 | **As one of** the largest... |
| 伴随/方式动作 | 现在分词 -ing | ..., **driving** regional growth |
| 已完成的前提/被支撑 | 过去分词 -ed | ..., **underpinned by** rich resources |
| 长定语"……的" | that/which 定语从句 | a circle **that is ideal for** work |
| 目的"为了/以" | to do / so as to | **to achieve** the goal |
| 原因/条件"随着/由于" | with + n. / as 从句 | **As** reform deepens... |

**第 4 步：补显性连接词**
中文省掉的逻辑（因果/转折/递进/目的），英文必须**补出来**：so/therefore（因果）、while/whereas（对比）、not only...but also（递进）、so that（目的）。

## 重构 vs 对译：同句对比
原文："随着改革开放的不断深入，大湾区的建设将进一步推动区域经济发展。"

- ❌ 对译（逐词）：With the reform and opening-up's continuous deepening, the Greater Bay Area's construction will further push the regional economy's development.
  → 三个 's 所有格堆叠、construction/push 选词中式、读着憋。
- ✅ 重构：**As** reform and opening-up **continue to deepen**, the development of the Greater Bay Area will **further fuel** regional economic growth.
  → "随着"用 As 从句，"不断深入"用 continue to deepen，主干 development...will fuel...growth 干净利落。

## 教练动作
批改时若发现学生**逐句对应、满篇 and、所有格堆叠、主语全是名词所有格**，判定为"对译思维"，第一刀先重构结构，再谈选词。

---

# 二、词汇与语境的精准映射

## 核心命题
**一个中文词不对应一个英文词，而是对应一个"语境—语域—搭配"的三维坐标。** 选词不是查词典选第一个，是问三个问题：这个词在**什么场景**？要多**正式**？和谁**搭配**？

## 三维坐标

**维度 1：语境义（同一个中文词，意思随上下文变）**
中文词常一词多义，必须看语境定英文。
- "发展"：经济发展 economic **development** / 发展会员 **recruit** members / 事态发展 how things **unfold**。
- "经济"：经济实力 the **economy** / 经济实惠 **economical** / 勤俭节约 **thrift**。
- "意思"：什么意思 **meaning** / 有意思 **interesting** / 小意思 a small **token**。
- 教练提醒：**先确定中文这个词在本句到底指什么，再选英文**，否则错译。

**维度 2：语域（正式度，决定能不能用）**
六级翻译题材是说明文/介绍文，**偏正式书面**。口语词会掉档。
| 中文 | 口语（低） | 书面（六级该用） |
|---|---|---|
| 很多 | a lot of | numerous / a large number of |
| 变好 | get better | improve / advance |
| 有名 | famous（可用但平） | renowned / celebrated |
| 重要 | important | crucial / vital / of great significance |
| 帮助 | help | facilitate / contribute to |
| 用 | use | employ / utilize / adopt |

**维度 3：搭配（collocation，词与词的化学键）**
英文词有固定"搭档"，选对单词但搭错伴=不地道甚至错。**记搭配，不记孤立单词。**
- 起作用：play a **vital** role（不是 do a role）
- 提供支撑：provide **support** for / be underpinned by
- 实现目标：achieve / fulfil / attain a **goal**（不是 realize a goal—中式）
- 推动增长：drive / fuel / spur **growth**（不是 push growth）
- 拥有优势：enjoy / boast an **advantage**

## 精准映射工作流（选词时走一遍）
1. **锁语境义**：中文这个词在本句指什么？（防一词多义错译）
2. **定语域**：说明文，偏正式 → 排除口语词。
3. **配搭档**：这个名词/动词的固定搭配是什么？成块取用。
4. **风险评估**：拿不准的"高级词"宁可不用——**错词比平词扣更多**（这是翻译，不是作文，求稳第一）。

## 反面案例（典型词境失配）
- "提高人民生活水平" → improve people's life level ❌（life level 不搭）→ **raise living standards** ✅
- "实现梦想" → realize the dream ❌（中式）→ **fulfil / achieve the dream** ✅
- "丰富的资源" → rich resources ✅ / plentiful resources ✅ / **abundant** resources ✅（都对，abundant 最贴正式语域）
- "得天独厚" → God-given ❌（语域/文化不符）→ **uniquely favorable / exceptionally advantageous** ✅

## 教练动作
看到选词问题，不要只给同义词，要给**语境义判断 + 语域定位 + 搭配块 + 风险提示**四件套（参见 chinglish-redlines.md 与 topic-vocab-bank.md）。

---

# 三、满分译文的隐性特质：连贯与地道

## 核心命题
达意零错 + 语法全对，只到 11–13。**11→14 的那道坎，是"连贯"和"地道"——这两样阅卷老师说不清但一眼能感觉到。** 它们是隐性的，因为不是单点对错，而是整段读起来"顺不顺、像不像英语母语者写的"。

## 连贯（Cohesion）：句子之间有没有"焊点"
一段译文不能是六个孤立句子并排站。母语者用四类"焊点"把句子粘起来：

**焊点 1：指代衔接（用代词/同义替换接上文）**
- 第一句 The Greater Bay Area... 第二句不必再重复全名，用 **this area / it** 接。
- 避免通篇重复 The Greater Bay Area（机械、不地道），用 it / this region / the Area 交替。

**焊点 2：连接词衔接（显性逻辑信号）**
- 递进：moreover / what's more / not only...but also
- 因果：therefore / as a result / consequently
- 对比：while / whereas / by contrast
- 时间/条件：as / once / by 2035
- **没有连接词的译文 = 一盘散沙**，这是中式译文最隐蔽的扣分点。

**焊点 3：信息流（旧信息在前，新信息在后 = end-weight）**
英文习惯"已知的放句首，强调的/新的放句尾"。
- 例：把"具有全球影响力的科技创新中心"这种**重磅长名词**放句尾（end-weight），读着才稳。

**焊点 4：平行结构（并列成分形式一致）**
- ideal for **work, shopping and tourism**（三个名词平行）
- not only **as** A but also **as** B（介词平行）
- 平行写崩 = 既不连贯也是语法硬伤。

## 地道（Idiomaticity）：像不像英语母语者
地道 = 用英语的"惯用表达方式"，而非把中文思维套上英文壳。四个识别点：

**① 动词扛起句子（英语是"动词的语言"）**
中文爱用"名词+做/进行/给予"，英文直接上实义动词。
- 进行改革 → carry out reform ❌偏 → **reform** ✅
- 给予帮助 → give help → **help / assist** ✅
- 对……产生影响 → produce influence on → **influence / shape** ✅
- 看到 get/make/have/do/give 这些"万能动词"，想能不能换成一个精准实义动词。

**② 少用范畴词（中文凑字，英文删）**
- 污染问题 the problem of pollution → **pollution**
- 发展水平 the level of development → **development**
- 加快建设的步伐 accelerate the pace of construction → **accelerate construction**

**③ 名词化与抽象表达（正式语体的标志）**
- "这件事很重要" It is important → 升级 **a position of strategic importance** / **of great significance**
- 把"形容词+句子"压成"名词短语"，是书面体地道感的来源。

**④ 静态优于动态（英语爱用 be/介词表状态）**
- "大湾区有完善的交通" The Bay Area has good transport → **The Bay Area is equipped with / boasts advanced transport**
- with / be characterized by / be home to 这类静态结构，比一连串动词更像英文说明文。

## 连贯地道自检（第 6 步检查时加问）
译完整段，**通读一遍**，问四句：
1. 句子之间有"焊点"吗？（代词/连接词接上了吗，还是六个孤句？）
2. 有没有机械重复同一个名词三次以上？
3. 动词是实义动词，还是一堆 make/have/do？
4. 有没有"名词+进行/给予"这种中式动词结构、范畴词冗余？

四个都过 = 摸到 14。

## 一段"达意但不地道" vs "满分"的对照
原文："大湾区具有得天独厚的地理位置，拥有完善的交通基础设施和丰富的产业资源。"

- 11 分（达意，但散+中式）：The Greater Bay Area has a very good geographical location. It has good transportation infrastructure. It also has rich industrial resources.
  → 三个 has、三个孤句、very good 口语——意思全对，但机械、不连贯、不地道。
- 14 分（连贯+地道）：The Greater Bay Area **boasts** a uniquely favorable geographical location, **underpinned by** advanced transportation infrastructure and abundant industrial resources.
  → boast 实义动词 + underpinned by 把后两项焊接成一句 + abundant 贴语域。一句话，立体、连贯、地道。

## 教练动作
当学生译文"挑不出明显错却总觉得不对劲、像翻译腔"，直接进入这一层：① 找散句加焊点；② 揪重复名词改代词；③ 万能动词换实义动词；④ 删范畴词。这是把 11 提到 14 的最后一公里。

---

# 三层透视速记（教练每次批改的顺序）
1. **结构层**：骨架对不对？（主句选对没、配料降级没、连接词补没）→ 错则先重构。
2. **词境层**：词选准没？（语境义对没、语域配没、搭配块对没）→ 错则换词给四件套。
3. **连贯地道层**：读起来像英语没？（焊点、去重复、实义动词、去范畴词）→ 这是 11→14 的坎。
**顺序不能反**：结构是地基，词境是砖墙，连贯地道是精装修。地基歪了不谈精装修。
