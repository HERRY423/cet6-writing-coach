# 中国特色词译法 + 音译加注规则

六级翻译必出文化负载词。卡住别留空、别硬翻——按下面规则处理。

## 处理三原则
1. **有通用译法就用通用译法**（春节、长城、孔子等约定俗成的，直接用）。
2. **没有通用译法的概念，用"音译 + 同位语解释"**：拼音斜体/正常 + 逗号 + 简短英文解释。
   - 古琴 → Guqin, **a traditional Chinese stringed instrument**
   - 旗袍 → Qipao, **a close-fitting Chinese dress**
   - 二十四节气 → the 24 solar terms, **a traditional Chinese calendar dividing the year into 24 periods**
3. **意译优先于生造**：能用英文现成词说清就别造词。"红包" → red envelope（已通用）；"压岁钱" → lucky money / money given to children during the Spring Festival。

> 实在不确定专名，**给一个达意的解释性译法也比留空强**——漏译直接降档。

## 朝代（首字母大写 + the ... Dynasty，注意时态用过去时）
| 中文 | 英文 |
|---|---|
| 夏 / 商 / 周 | the Xia / Shang / Zhou Dynasty |
| 秦 / 汉 | the Qin / Han Dynasty |
| 唐 / 宋 / 元 / 明 / 清 | the Tang / Song / Yuan / Ming / Qing Dynasty |
| 春秋时期 | the Spring and Autumn Period |
| 战国时期 | the Warring States Period |
| 公元前 7 世纪 | the 7th century BC |
| 公元 2 世纪 | the 2nd century AD |

## 节日（首字母大写）
| 中文 | 英文 |
|---|---|
| 春节 | the Spring Festival / Chinese New Year |
| 元宵节 | the Lantern Festival |
| 清明节 | the Tomb-Sweeping Day / Qingming Festival |
| 端午节 | the Dragon Boat Festival |
| 中秋节 | the Mid-Autumn Festival |
| 重阳节 | the Double Ninth Festival |
| 除夕 | New Year's Eve |

## 文化 / 工艺 / 艺术
| 中文 | 英文 |
|---|---|
| 京剧 | Peking Opera |
| 书法 | calligraphy |
| 国画 / 水墨画 | traditional Chinese painting / ink-wash painting |
| 剪纸 | paper cutting / paper-cut |
| 刺绣 | embroidery |
| 陶瓷 / 瓷器 | ceramics / porcelain / china |
| 丝绸 | silk |
| 中国结 | the Chinese knot |
| 四大发明 | the Four Great Inventions（造纸术 papermaking、印刷术 printing、火药 gunpowder、指南针 the compass） |
| 太极 | Tai Chi |
| 武术 | martial arts |
| 儒家思想 | Confucianism |
| 道教 | Taoism |
| 丝绸之路 | the Silk Road |

## 概念 / 价值 / 社会
| 中文 | 英文 |
|---|---|
| 和谐社会 | a harmonious society |
| 小康社会 | a moderately prosperous society |
| 改革开放 | reform and opening-up |
| 一带一路 | the Belt and Road Initiative |
| 可持续发展 | sustainable development |
| 全面建成小康社会 | building a moderately prosperous society in all respects |
| 中华民族 | the Chinese nation |
| 团圆 | family reunion |
| 孝道 | filial piety |

## 饮食
| 中文 | 英文 |
|---|---|
| 饺子 | dumplings / jiaozi |
| 粽子 | zongzi, **glutinous rice wrapped in bamboo leaves** |
| 月饼 | mooncake |
| 春卷 | spring rolls |
| 火锅 | hot pot |
| 茶文化 | tea culture |

## 加注写法示范（同位语万能模板）
> **[音译/专名] , [a/an + 类别名词 + 关键特征 / that 从句] .**

- 风水 → Feng Shui, an ancient Chinese practice of arranging space to achieve harmony with the environment.
- 京剧脸谱 → Peking Opera masks, the colorful facial paintings that represent characters' personalities.
- 二十四节气 → the 24 solar terms, which guide farming activities throughout the year.
